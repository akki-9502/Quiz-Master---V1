from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()
# The db object is an instance of the SQLAlchemy class. This object will be our entry point to the database.